*------------------------------------------------------*
            T I R E D  T E R R O R I S T
*------------------------------------------------------*

 Hello, is any members of Baader Meinhof in the
 audience?? Lets hear it.. Terror! Terror! Terror!
 Oh, here they come.. Are you feeling good, guys?
 Aha, you're tired.. Tired of blowing planes up and
 stuff? mmh, no answer.. al'righty.. 
 Let the show begin..

 WRITE ME A LETTER AND SAY IF THE FONT IS OK, AND SAY
 THANKS. REMEMBER THIS IS NOT FREEWARE, ITS LETTERWARE
 
 Donate your salary to me -> contact: fonts@mrfisk.com

*------------------------------------------------------*

 ATTENTION!
 And if one of you use this or any other of my fonts for 
 commercial shit I will contact the FBI and Nasdaq and
 the holy mother Maria to spank you beyond recognition.

 Read the faq on my site, and follow the rules.
 It is very simple : You can use my free fonts on 
 FREE things, nothing else.

*------------------------------------------------------*

 Have a nice day. / MR.FISK - 01:41 2000-11-06 - Sweden

*------------------------------------------------------*
 
 Say at least THANKS, 
 write to; baader.meinhof@mrfisk.com

*------------------------------------------------------*

 Hail Satan!      

                    OOOO
                    OOOO
                    OOOO
                    OOOO
                    OOOO
                    OOOO
                    OOOO
             OOOOOOOOOOOOOOOOOO
             OOOOOOOOOOOOOOOOOO
                    OOOO
                    OOOO
                    OOOO                   He he he...